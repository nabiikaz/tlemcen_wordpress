<svg width="15px" height="16px" viewBox="0 0 15 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs></defs>
    <g id="Page---Listing" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Icon-Slicing" transform="translate(-36.000000, 0.000000)" fill="currentColor">
            <path d="M36,14.5981841 C36,4.64082407 44.3594,4.68562407 44.3594,4.68562407 L44.3594,1.48858407 L50.93716,7.15298407 L44.3594,12.6799041 L44.3594,9.39522407 C44.3594,9.39522407 39.24296,7.92970407 36,14.5981841 L36,14.5981841 Z" id="Imported-Layers-Copy-8"></path>
        </g>
    </g>
</svg>
