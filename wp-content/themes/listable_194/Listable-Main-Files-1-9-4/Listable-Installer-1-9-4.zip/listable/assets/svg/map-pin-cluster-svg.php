<svg width="50px" height="62px" viewBox="0 0 50 62" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-1">
            <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="1" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowBlurOuter1" type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
            <feMerge>
                <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
        <path id="unique-path-2" d="M6.75141997,6.76666667 C0.287315594,13.2746963 -1.50665686,22.6191407 1.24745785,30.7382815 C7.20204673,48.0746963 23.0106822,58 23.0106822,58 C23.0106822,58 38.6298497,48.1382815 44.6475946,30.9969185 C44.6475946,30.9333333 44.7107506,30.8697481 44.7107506,30.8027259 C47.5280214,22.6191407 45.7340489,13.2746963 39.2699445,6.76666667 C30.3086168,-2.25555556 15.7127477,-2.25555556 6.75141997,6.76666667 Z"></path>
        <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-3">
            <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="1" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowBlurOuter1" type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
            <feMerge>
                <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
        <path id="unique-path-4" d="M8.87079997,8.83664825 C3.24983965,14.4470186 1.6898636,22.5025742 4.08474595,29.5018334 C9.26264933,44.4470186 23.0092889,53.0033149 23.0092889,53.0033149 C23.0092889,53.0033149 36.5911736,44.5018334 41.8239953,29.7247964 C41.8239953,29.6699816 41.8789136,29.6151668 41.8789136,29.557389 C44.3287142,22.5025742 42.7687382,14.4470186 37.1477778,8.83664825 C29.355319,1.05887047 16.6632588,1.05887047 8.87079997,8.83664825 Z"></path>
        <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-5">
            <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="1" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowBlurOuter1" type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
            <feMerge>
                <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
        <path id="unique-path-6" d="M10.28372,10.25 C5.22485568,15.2993333 3.82087724,22.5493333 5.97627136,28.8486667 C10.6363844,42.2993333 23.00836,50 23.00836,50 C23.00836,50 35.2320563,42.3486667 39.9415958,29.0493333 C39.9415958,29 39.9910222,28.9506667 39.9910222,28.8986667 C42.1958428,22.5493333 40.7918644,15.2993333 35.7330001,10.25 C28.7197871,3.25 17.296933,3.25 10.28372,10.25 Z"></path>
        <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-7">
            <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="1" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowBlurOuter1" type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
            <feMerge>
                <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
        <path id="unique-path-8" d="M11.69664,11.6666667 C7.19987172,16.154963 5.95189088,22.5994074 7.86779676,28.1988148 C12.0101195,40.154963 23.0074311,47 23.0074311,47 C23.0074311,47 33.8729389,40.1988148 38.0591962,28.3771852 C38.0591962,28.3333333 38.1031309,28.2894815 38.1031309,28.2432593 C40.0629714,22.5994074 38.8149905,16.154963 34.3182223,11.6666667 C28.0842552,5.44444444 17.9306071,5.44444444 11.69664,11.6666667 Z"></path>
    </defs>
    <g id="Page---Listings-Archive" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Pin-4" transform="translate(2.000000, 1.000000)">
            <g id="Pin-Copy-4" filter="url(#filter-1)">
                <use fill="#FFFFFF" xlink:href="#unique-path-2"></use>
                <use id="svgCluster1" fill="currentColor" xlink:href="#unique-path-2"></use>
            </g>
            <g id="Pin-Copy-3" filter="url(#filter-3)">
                <use fill="#FFFFFF" fill-rule="evenodd" xlink:href="#unique-path-4"></use>
                <use id="svgCluster2" fill="none" xlink:href="#unique-path-4"></use>
            </g>
            <g id="Pin-Copy-6" filter="url(#filter-5)">
                <use fill="#FFFFFF" fill-rule="evenodd" xlink:href="#unique-path-6"></use>
                <use id="svgCluster3" fill="none" xlink:href="#unique-path-6"></use>
            </g>
            <g id="Pin-Copy-5" filter="url(#filter-7)">
                <use fill="#FFFFFF" fill-rule="evenodd" xlink:href="#unique-path-8"></use>
                <use id="svgCluster4" fill="none" xlink:href="#unique-path-8"></use>
            </g>
        </g>
    </g>
</svg>
