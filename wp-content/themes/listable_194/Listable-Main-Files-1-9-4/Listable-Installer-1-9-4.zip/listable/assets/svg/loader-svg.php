<svg class="loader" width="40px" height="40px" viewBox="0 0 40 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <linearGradient x1="50%" y1="7.52257671%" x2="50%" y2="100%" id="linearGradient-1">
            <stop stop-color="currentColor" stop-opacity="0.5" offset="0%"></stop>
            <stop stop-color="currentColor" stop-opacity="0" offset="100%"></stop>
        </linearGradient>
        <linearGradient x1="50%" y1="7.70206696%" x2="50%" y2="100%" id="linearGradient-2">
            <stop stop-color="currentColor" stop-opacity="0.5" offset="0%"></stop>
            <stop stop-color="currentColor" offset="100%"></stop>
        </linearGradient>
    </defs>
    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g>
            <path d="M20,0 C31.045695,0 40,8.954305 40,20 C40,31.045695 31.045695,40 20,40 L20,38 C29.9411255,38 38,29.9411255 38,20 C38,10.0588745 29.9411255,2 20,2 L20,0 Z" id="Oval-1" fill="url(#linearGradient-1)"></path>
            <path d="M20,0 C8.954305,0 0,8.954305 0,20 C0,31.045695 8.954305,40 20,40 L20,38 C10.0588745,38 2,29.9411255 2,20 C2,10.0588745 10.0588745,2 20,2 L20,0 Z" id="Oval-1-Copy" fill="url(#linearGradient-2)"></path>
        </g>
    </g>
</svg>
